#%%
class testowa():
    bok_a = 5
    bok_b = 10
    obiekty = 0

    def __init__(self):
       self.numer = 15

    def __str__(self):
        f"{self.numer}"


    def sumowanie(self):
        c = self.bok_a + self.bok_b
        testowa.obiekty += 1
        return f"Długośc boku wynosi {c}, ilość obiektów wynosi: {testowa.obiekty}"

    
suma = testowa().sumowanie()
suma1 = testowa()
suma1.sumowanie()

testowa_lista = []
zbior = set()
if len(testowa_lista) < 1:
    print("Pusta lista")
if not testowa_lista:
    print("Pusta lista")
if testowa_lista:
    zbior.add(testowa_lista[0])
    print("Pusta lista")
    print("zbior")

print("*"*20)

numer = 20
numer_fl = -20.155

print(type(numer))
print(type(numer_fl))

slownik1 = {"a":"7"}
slownik2 = {"a":"9"}
lista_slownikow = []
lista_slownikow.append(slownik1)
lista_slownikow.append(slownik2)
print(lista_slownikow)
#%%
from zyski.pakiety import tabele
class Wyniki():
    """Klasa do obliczenia zysków ciepła w pomieszczeniach"""
    def __init__(self):
        self.godziny_people = {str(key) : value for (key, value) in enumerate([hour for hour in range(8,21)],start=8)}
        self.godziny_lights = self.godziny_people.copy()
        self.godziny_air = {}
        self.godziny_sciany = {}

    def calc_gains_people(self,people,watts):
        """Metoda do obliczenia zysków od ludzi. Wynik to słownik."""
        for key, value in self.godziny_people.items():
            self.godziny_people[key] = people * watts
        return self.godziny_people
    
    def calc_gains_lights(self,area,watts,a=0,b=0.3):
        """Metoda do obliczenia zysków od oświetlenia. Wynik to słownik."""
        for key, value in self.godziny_lights.items():
            if key == "19":
                ko = 0.35
                self.godziny_lights[key] = round(area * watts * ((ko * (1-b-a)) + b))
            elif key == "20":
                ko = 0.60
                self.godziny_lights[key] = round(area * watts * ((ko * (1-b-a))+b))
            else:
                ko = 0.0
                self.godziny_lights[key] = (area * watts * ((ko * (1-b-a))+b)) * 0
        return self.godziny_lights

    def calc_gains_air(self,ti=24,air=0):
        """Metoda do obliczenia zysków od infiltracji. 
        ti - temp. wewn. w pomieszczeniu (zmienna),
        air - strumień powietrza infiltrującego w m3/h,
        te - temp. zewnętrzna stała od +18*C do +32 """
        #słownik temperatur zewnętrznych
        te = {
            "8":24, "9":24, "10":26, "11":26,"12":32,
              "13":32, "14":32, "15":30, "16":28, "17":26,
              "18":24, "19":20, "20":18
        }
        for key, value in te.items():
            self.godziny_air[key] = round(air / 3600 * 1.2 * (value-ti) * 1000)
            self.godziny_air 
        return self.godziny_air
    
    def calc_gains_walls(self, ti=26, tesr=24.5, kierunek="N", klasa ="1",
                         area = 0, U = 0):
        """
        Metoda do obliczenia zysków ciepła od ścian. Polega na pobraniu danej ściany,
        sprawdzeniu jej kierunku świata oraz klasy przegrody i obliczeniu zysków ciepła 
        dla jednej przegrody co godzinę. Wynikiem jest słownik z jedną ścianą a następnie 
        inkrementacja do głównego ślownika wszystkich ścian. Metoda będzie dodawać wartości 
        do głównego słownika za każdym razem od jej wywołania. 
        Główny słownik zostaje przypisany do instancji class Wyniki. Słownik: self.godziny_sciany = {}
        """
        one_wall = tabele.klasy[f"Klasa_{klasa}_{kierunek}"]
        one_wall_result = { key : round(area*U*(value + tesr - 24.5 - ti + 22)) for key, value in one_wall.items()}
        self.godziny_sciany.update({key: self.godziny_sciany.get(key, 0) + value for key, value in one_wall_result.items()})
        
        return  self.godziny_sciany


sciana1 = Wyniki()
sciana1.calc_gains_walls(kierunek="N", klasa ="1",
                         area = 100, U = 0.3)
sciana1.calc_gains_walls(kierunek="S", klasa ="1",
                         area = 200, U = 0.3)

print(sciana1.godziny_sciany)




# %%
a=5/(-1)
print(a)

# %%
lista1=[1,2,3,4,5]
lista2=[1,2,3,4,5]
print([(x+lista2[idx]) for idx, x in enumerate(lista1) ])
print({ key : 0 for key in [x for x in range(8,21)]})
print({ key : value for key, value in enumerate([0 for x in range(8,21)],start=8)})

# %%
from zyski.pakiety import tabele
kierunek, klasa = "W", "1"
a,u = 0,0

start_dict = tabele.Klasa_1_N if kierunek == "N" else None
if start_dict is None: start_dict = tabele.Klasa_1_W if (kierunek == "W" and klasa == "1") else None
if start_dict is None: start_dict = tabele.Klasa_1_W if (kierunek == "SW" and klasa == "1") else None
print({key : value*a*u for key, value in start_dict.items()})
# %%

dict1 = {"8":10, "9":10}
dict2 = {"8":10, "9":10}

# for key, value in dict2.items():
#     update = dict1.get(key,0)
#     dict1[key] = update + value

dict1.update({key: dict1.get(key, 0) + value for key, value in dict2.items()})


print(dict1)
# %%
