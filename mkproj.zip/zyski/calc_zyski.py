from zyski.pakiety import tabele

class Wyniki():
    """Klasa do obliczenia zysków ciepła w pomieszczeniach"""
    def __init__(self):
        self.godziny_people = {str(key) : value for (key, value) in enumerate([hour for hour in range(8,21)],start=8)}
        self.godziny_lights = self.godziny_people.copy()
        self.godziny_devices = self.godziny_people.copy()
        self.godziny_air = {}
        self.godziny_sciany = {}

    def calc_gains_people(self,people,watts):
        """Metoda do obliczenia zysków od ludzi. Wynik to słownik."""
        for key, value in self.godziny_people.items():
            self.godziny_people[key] = people * watts
        return self.godziny_people
    
    def calc_gains_devices(self,watts=0):
        """Metoda do ibliczenia zysków od urządzeń. Wynik to słownik."""
        for key, value in self.godziny_devices.items():
            self.godziny_devices[key] = watts
        return self.godziny_devices
    
    def calc_gains_lights(self,area,watts,a=0,b=0.3):
        """Metoda do obliczenia zysków od oświetlenia. Wynik to słownik."""
        for key, value in self.godziny_lights.items():
            if key == "19":
                ko = 0.35
                self.godziny_lights[key] = round(area * watts * ((ko * (1-b-a)) + b))
            elif key == "20":
                ko = 0.60
                self.godziny_lights[key] = round(area * watts * ((ko * (1-b-a))+b))
            else:
                ko = 0.0
                self.godziny_lights[key] = (area * watts * ((ko * (1-b-a))+b)) * 0
        return self.godziny_lights
    
    def calc_gains_air(self,ti=24,air=0):
        """Metoda do obliczenia zysków od infiltracji. 
        ti - temp. wewn. w pomieszczeniu (zmienna),
        air - strumień powietrza infiltrującego w m3/h,
        te - temp. zewnętrzna stała od +18*C do +32 """
        #słownik temperatur zewnętrznych
        te = {
            "8":24, "9":24, "10":26, "11":26,"12":32,
            "13":32, "14":32, "15":30, "16":28, "17":26,
            "18":24, "19":20, "20":18
        }
        for key, value in te.items():
            self.godziny_air[key] = round(air / 3600 * 1.2 * (value-ti) * 1000)
        return self.godziny_air

    def calc_gains_walls(self, ti=26, tesr=24.5, kierunek="N", klasa ="1",
                        area = 0, U = 0):
        """
        Metoda do obliczenia zysków ciepła od ścian. Polega na pobraniu danej ściany,
        sprawdzeniu jej kierunku świata oraz klasy przegrody i obliczeniu zysków ciepła 
        dla jednej przegrody co godzinę. Wynikiem jest słownik z jedną ścianą a następnie 
        inkrementacja do głównego ślownika wszystkich ścian. Metoda będzie dodawać wartości 
        do głównego słownika za każdym razem od jej wywołania. 
        Główny słownik zostaje przypisany do instancji class Wyniki. Słownik: self.godziny_sciany = {}
        """
        one_wall = tabele.klasy[f"Klasa_{klasa}_{kierunek}"]
        one_wall_result = { key : round(area*U*(value + tesr - 24.5 - ti + 22)) for key, value in one_wall.items()}
        self.godziny_sciany.update({key: self.godziny_sciany.get(key, 0) + value for key, value in one_wall_result.items()})
        
        return  self.godziny_sciany





if __name__ == "__main__":
    test = Wyniki()
    print(test.godziny_people)
    new_list=[{'8': 1100, '9': 2500, '10': 2300},{'8': 1200, '9': 2700, '10': 2400}]
    for i,j in enumerate(new_list):
        print(sorted(new_list[i].items(), key=lambda x: x[1])[-1]) #sortowanie po wartościach słowników
    print([(key,value) for key, value in new_list[0].items() if value == max(new_list[0].values())]) #MAX z 0 elementu listy słowników

